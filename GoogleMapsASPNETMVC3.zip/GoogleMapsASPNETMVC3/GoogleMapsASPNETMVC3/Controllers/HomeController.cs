﻿using System.Web.Mvc;
using GoogleMapsASPNETMVC3.Models;

namespace GoogleMapsASPNETMVC3.Controllers
{
    public class HomeController : Controller
    {
        private readonly MarkerRepository _markerRepository;
        public HomeController()
        {
            _markerRepository = new MarkerRepository();
        }

        public ActionResult Index()
        {
            ViewBag.Message = "Welcome to ASP.NET MVC!";

            return View();
        }

        [HttpGet]
        public ActionResult Sync()
        {
            return View(_markerRepository.GetMarkers());
        }

        [HttpGet]
        public ActionResult Async()
        {
            return View();
        }

        [HttpPost]
        public ActionResult GetMarkersAsync()
        {
            return Json(_markerRepository.GetMarkers());
        }
    }
}
